console.log("Hello, World!");

var trace1 = {
  x: ['Australia', 'Canada', 'China', 'India', 'New Zealand', 'USA'],
  y: [11.654,
    6.61,
    5.983,
    1.498,
    0.425,
    0.008
  ],
  marker: {
    color: ['rgba(222,45,38,0.8)', 'rgba(41, 148, 27,0.8)', 'rgba(14, 105, 217,0.8)', 'rgba(14, 105, 217,0.8)', 'rgba(41, 148, 27,0.8)',  'rgba(41, 148, 27,0.8)']
  },

  //colours correlate to previous graph and their respective classification of worlds
  type: 'bar'
};

var data = [trace1];

var layout = {



  yaxis: {
    title: 'Co2 per Capita in Tonnes',
    showgrid: false,
    fixedrange: true, //disable zoom to prevent users from accidentally clicking
  },
  paper_bgcolor:'rgba(0,0,0,0)',
  plot_bgcolor:'rgba(0,0,0,0)',//remove background
};



var config = {
  responsive: true
}

Plotly.newPlot('myDiv', data, layout, {
  displayModeBar: false
}, config); // disable mode to reduce confusion