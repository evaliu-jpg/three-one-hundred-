var trace1 = {
  x:["0 months","3 months"],
  //x: [January, March, June, October, December], from a previous idea
  y: [ 0,0.078],
  mode: 'lines', // middle line, shows driving less impact.
  name: 'Drive Less',
  line: {
    dash: 'dashdot', //shows that this is predictive and average 
    width: 4,
    color:'rgba(41, 148, 27,0.8)',
  }
};

var trace2 = {
  x:["0 months","3 months"],
  y: [0, 0.195],
  mode: 'lines',
  name: 'Catch Train', // shows numbers at half the impact. 
  line: {
    dash: 'dashdot',
    width: 4,
    color: 'rgb(255, 218, 3)',
  }
};

var trace3 = {
  x:["0 months","3 months"], //allows readers to understand that this is an average.
  y: [0, 0.39],
  mode: 'lines',
  name: 'No Change', // shows no change or commitment to change. 
  line: {
    dash: 'solid',
    width: 4,
    color: 'rgba(222,45,38,0.8)',
  }
};

var data = [trace1, trace2, trace3];

var layout = {

  
  
  xaxis: {
    title: {
      text: 'Months',},
    
    //range: ["January","February", "March"],
    autorange: true,
    showgrid: false,
    zeroline: false,
    //visible: false,
  },
  yaxis: {
    range: [0, 0.4],
    autorange: false,
    showgrid: false, //hide grid 
    title: {
      text: 'C02 Emissions From Car in Tonnes',},
  },
  showlegend: false,
  paper_bgcolor:'rgba(0,0,0,0)',
  plot_bgcolor:'rgba(0,0,0,0)', //hide background
};

Plotly.newPlot('myLine', data, layout, {
  displayModeBar: false
});