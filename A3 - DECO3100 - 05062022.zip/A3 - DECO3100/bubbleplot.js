Plotly.d3.csv('https://raw.githubusercontent.com/evaliu-jpg/ok/main/bubble_updated.csv', function (err, data) {
    var lookup = {};

    //create lookup to group data for plotly
    function getData(year, world) {
        var byYear, trace;
        if (!(byYear = lookup[year])) {
            ;
            byYear = lookup[year] = {};
        }

        // if world is blank then fill it in

        if (!(trace = byYear[world])) {
            trace = byYear[world] = {
                x: [],
                y: [],
                id: [],
                text: [],
                marker: {
                    size: []
                }
            };
        }
        return trace;
    }
//go through each colunm and get the data, create trace. 
    for (var i = 0; i < data.length; i++) {
        var datum = data[i];
        var trace = getData(datum.year, datum.world);
        trace.text.push(datum.country);
        trace.id.push(datum.country);
        trace.x.push(datum.pop);
        trace.y.push(datum.co2_per_capita);
        trace.marker.size.push(datum.pop);

    }

    //get names grouped
    var years = Object.keys(lookup);
// every countries' classification is the same so across 2008-2012 just use the first year.

    var firstYear = lookup[years[0]];
    var worlds = Object.keys(firstYear);

    //create trace for each first world, second and third world country
    //slice array to prevent error in lookup table

    var traces = [];
    for (i = 0; i < worlds.length; i++) {
        var data = firstYear[worlds[i]];
        traces.push({
            name: worlds[i],
            x: data.x.slice(),
            y: data.y.slice(),
            id: data.id.slice(),
            text: data.text.slice(),
            mode: 'markers',
            marker: {
                size: data.marker.size.slice(),
                sizemode: 'area',
                sizeref: 299000, //size of bubbles, diameters


            }
        });
    }
//single trace but every country passes through the data 
// frame = trace
    var frames = [];
    for (i = 0; i < years.length; i++) {
        frames.push({
            name: years[i],
            data: worlds.map(function (world) {
                return getData(years[i], world);
            })
        })
    }
//create slider steps
// execute plotly animate

    var sliderSteps = [];
    for (i = 0; i < years.length; i++) {
        sliderSteps.push({
            method: 'animate',
            label: years[i],
            args: [
                [years[i]], {
                    mode: 'immediate',
                    transition: {
                        duration: 300
                    },
                    frame: {
                        duration: 300,
                        redraw: false
                    },
                }
            ]
        });
    }

    //adjustments to layout 

    var layout = {
        autosize: false,
        width: 414,
        height: 600,
        paper_bgcolor:'rgba(0,0,0,0)',
        plot_bgcolor:'rgba(0,0,0,0)',


        // showlegend: true,
        // legend: {"orientation": "h"},
        legend: {
            //changes legend formatting and position 
            x: 5,
            y: 1.2, //POSITION TOP LEFT F ON Y AXIS
            traceorder: 'normal',
            font: {
                family: 'sans-serif',
                size: 10,
                color: '#000'
            },
        },


        xaxis: {
            title: 'Population',
            type: 'log', // graph is more spread out exponentially along x-axis
            //range: [1, 2],
            showgrid: false, //hide gride lines as plot is interactive
            fixedrange: true, //disable zoom to prevent users from accidentally clicking

        },
        yaxis: {
            title: 'CO2 Per Capita in Ton',
            type: 'log', // exponentially shows graph 
            showgrid: false,
            fixedrange: true, //disable zoom to prevent users from accidentally clicking
            automargin: true, // increase margins so graph is easier to access on mobile, autoscale
        },
        hovermode: 'closest',
        updatemenus: [{
            x: 0,
            y: 0,
            yanchor: 'top',
            xanchor: 'left',
            showactive: false,
            direction: 'left',
            type: 'buttons',
            pad: {
                t: 150,
                r: 3
            },
            buttons: [{
                method: 'animate',
                args: [null, {
                    mode: 'immediate',
                    fromcurrent: true,
                    transition: {
                        duration: 300
                    },
                    frame: {
                        duration: 500,
                        redraw: false
                    }
                }],
                label: 'Play'
            }, {
                method: 'animate',
                args: [
                    [null], {
                        mode: 'immediate',
                        transition: {
                            duration: 0
                        },
                        frame: {
                            duration: 0,
                            redraw: false
                        }
                    }
                ],
                label: 'Pause'
            }]
        }],
        sliders: [{
            pad: { // padding for slider
                l: 13,
                t: 55,
                r: 0,
            },
            currentvalue: {
                visible: true,
                prefix: 'Year:',
                xanchor: 'left',
                font: {
                    size: 15,
                    color: '#666'
                }
            },
            steps: sliderSteps
        }]

    };
    var config = {
        responsive: true, //ensure plot adjusts resizes to iPhone Xr sizing
        displayModeBar: false, //remove modebar so users aren't confused 
    }
    // Create the plot:
    Plotly.plot('myBu', {
        data: traces,
        layout: layout,
        frames: frames,


        config: {
            showSendToCloud: true,
            displayModeBar: false //remove modebar so users aren't confused 

        }




    }, {

    });

});

console.log(Plotly.BUILD);